PRINCE CORPORATE DEVELOPMENT NIG LTD — WEBSITE
================================================

Included:
- index.html
- images/ (your uploaded photos)
- Mobile responsive design
- WhatsApp ordering/quote buttons
- Instagram link
- Football jersey pricing:
  Player Version: ₦30,000
  Fan Version: ₦25,000
  Customization available
  Prices may change based on stock/design/customization.
- POP & gypsum installation
- Cleaning services
- Furniture and modern interiors sections

FREE HOSTING OPTION:
1. Create a free account on GitHub.
2. Create a new public repository, e.g. prince-corporate-website.
3. Upload index.html and the images folder.
4. In repository Settings > Pages, select "Deploy from a branch", choose the main branch and root folder.
5. GitHub will provide a free website address that you can put in your Instagram bio.

IMPORTANT:
The site is ready to edit. Replace/add images and text whenever you have more products or completed projects.
